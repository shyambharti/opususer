const mysql = require('mysql');

//create mysql connection
const dbCon=mysql.createConnection({
host : 'localhost',
user : 'root',
password : 'root',
database : 'opus'
});

dbCon.connect(function(error){
if(error) throw error;
console.log('Database connected sucessfully');
});

module.exports = dbCon;