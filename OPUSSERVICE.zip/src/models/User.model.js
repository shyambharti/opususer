var dbCon = require('../../config/db.config');

var User = function(user){
    this.first_name = user.first_name;
    this.last_name = user.last_name;
    this.email = user.email;
    this.user_id = user.user_id;
    
} 

//get all user
User.getAllUser = (result)=>{
    dbCon.query('select * from opus_user',(error,res)=>{
        if(error){
            console.log('Error while fetching the User',error);
            result(null,error);
        }else{
            console.log('User Fetching Successfully');
            result(null,res);
        }
    })

}

//get user by Id from db
User.getUserById = (Id,result)=>{
dbCon.query('select * from opus_user where id=?',Id,(error,res)=>{
    if(error){
        console.log('Error while fetching User by Id',error);
        result(null,error);
    }else{
        result(null,res);
    }
})
}

//Create new user
User.createUser = (user,result)=>{
    dbCon.query('insert into opus_user set ?',user,(error,res)=>{
        if(error){
            console.log('Error while  inserting data');
            result(null,error);
        }else{
            console.log('User Created Successfully');
            //result(null,{status: true,message:'User Created Successfully',insertId:res.id})
            result(null,res)
        }

    })
}

//update User
User.updateUser = (id,userReqData,result)=>{
    dbCon.query("update opus_user set first_name=?,last_name=?,email=?,user_id=? where id=?",[userReqData.first_name,userReqData.last_name,userReqData.email,userReqData.user_id,id],
    (error,res)=>{
        if(error){
            console.log('Error while updating user');
            result(null,error);
        }else{
            console.log("User Updated Sucessfully")
            result(null,res);
        }
    })

}

//delete user
User.deleteUser = (Id,result)=>{
    dbCon.query('DELETE FROM OPUS_USER where id=?',[Id],(error,res)=>{
        if(error){
            console.log("Error while user deleting");
            result(null,error);
        }else{
            result(null,res);
        }
    })
}

module.exports = User;