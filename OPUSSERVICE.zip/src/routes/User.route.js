const express = require('express');
const router = express.Router();

const userController = require('../controllers/User.controller');

//get all User
router.get('/' ,userController.getUserList);

//get User by Id
router.get('/:Id',userController.getUserById);

//create new user
router.post('/',userController.createUser);

//update user
router.put('/:Id',userController.updateUser);

//delete user
router.delete('/:Id',userController.deleteUser);

module.exports = router;