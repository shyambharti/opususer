const User = require('../models/User.model');
const UserModel = require('../models/User.model')

//create all user list
exports.getUserList = (req,res)=>{
//console.log('All user list');
UserModel.getAllUser((error,user)=>{
    //console.log('I am here');
    if(error)
    res.send(error);
    res.send(user);
})
}

//get User by Id
exports.getUserById = (req,res)=>{
    //console.log('get by user Id');
    UserModel.getUserById(req.params.Id,(error,user)=>{
        if(error)
        res.send(error);
        res.send(user);
    })
}

//create new User 
exports.createUser = (req,res)=>{
    console.log('create a new user',req.body);
    const userReqData = new User(req.body);
    //check null 
    if(req.body.constructor === Object && Object.keys(req.body).length === 0 ){
        res.send(400).send({success:false,message: 'Please fill all fields'});
    }else{
        console.log('valid Data');
        UserModel.createUser(userReqData,(error,user)=>{
            if(error)
            res.send(error);
            res.json({status: true,message:'User Created Sucessfully ', data: user})
        })
    }
}

//update user
exports.updateUser = (req,res)=>{
    const userReqData = new User(req.body);
    //check null 
    if(req.body.constructor === Object && Object.keys(req.body).length === 0 ){
        res.send(400).send({success:false,message: 'Please fill all fields'});
    }else{
        console.log('valid Data');
        UserModel.updateUser(req.params.Id,userReqData,(error,user)=>{
            if(error)
            res.send(error);
            res.json({status: true,message:'User updated Sucessfully ', data: user.Id})
        })
    }
}

//delete user
exports.deleteUser = (req,res)=>{
    UserModel.deleteUser(req.params.Id,(error,user)=>{
        if(error)
        res.send(error);
        res.json({success: true, message: 'User deleted successfully',data: user.Id});
    })
}