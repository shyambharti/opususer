import React from "react";
import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import Home from  "./component/pages/Home";
import About from "./component/pages/About";
import Contact from "./component/Contact";
import Navigation from "./component/layout/Navigation";
import {BrowserRouter as Router,Route,Switch} from "react-router-dom";
import AddUser from "./component/users/AddUser";
import EditUser from "./component/users/EditUser";
import ViewUser from "./component/users/ViewUser";

function App() {
  return (
   <Router>
      <div className="App">
      
   <Navigation/>
 
   <switch>
    <Route exact path="/" component={Home}></Route>
    <Route exact path="/about" component={About}></Route>
    <Route exact path="/contact" component={Contact}></Route>
    <Route exact path="/addUser" component={AddUser}></Route>
    <Route exact path="/editUser/:id" component={EditUser}></Route>
    <Route exact path="/viewUser/:id" component={ViewUser}/>
   </switch>
 
   </div>
   </Router>
  );
};

export default App;
