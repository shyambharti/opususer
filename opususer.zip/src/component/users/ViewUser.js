import Axios from "axios";
import React, {useEffect, useState} from "react";
import {Link , useParams } from "react-router-dom";



const ViewUser = () => {
    const [user,setUser] = useState({
        firstname: "",
        lastname: "",
        email: ""
    });

    const { id } = useParams();

    useEffect(() => {
        loadUser();
    }, []);

    const loadUser = async () =>{
        const result = await Axios.get(`http://localhost:3003/users/${id}`);
        setUser(result.data);
    }

    return (
       <div className="container">
           <Link className="btn btn-primary" to="/">
               Back To Home
           </Link>
           <h3 className="display-6">User: {user.firstname}</h3>
           <hr/>
           <ul className="list-group w-50">
               <li className="list-group-item">First Name: {user.firstname}</li>
               <li className="list-group-item">Last Name: {user.lastname}</li>
               <li className="list-group-item">Email: {user.email}</li>
           </ul>
       </div>
    );
};

export default ViewUser;