import Axios from "axios";
import React, {useState} from "react";
import {useHistory} from "react-router-dom";

const Login =() =>{
    let history = useHistory();

    const [user,setUser] = useState({
            user_id: "",
            password: ""
    });

    const { user_id, password } = user;
    const onInputChange = e => {
        console.log(e.target.value);
        setUser({ ...user,[e.target.name]: e.target.value});
    };

    const onSubmit = async e => {
        e.preventDefault();
        await Axios.get(`http://localhost:5000/opus/user/login/${user_id}/${password}`,user);
        alert("User Successfully Logined");
        history.push("/opusUsers");

    };

    return (
        
        <div className="container">
        <div className="py-4">
        <h3>OPUS USERS LOGIN</h3>

        <form onSubmit={e => onSubmit(e)}>
        <div class="form-group">
          <label for="exampleInputUserId">User Id</label>
          <input type="text"   className="form-control form-control-lg"
            placeholder="Enter Your User Id"
            name="user_id"
            value={user_id} 
            onChange={e => onInputChange(e)}/>
         
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input type="password"  className="form-control form-control-lg"
            placeholder="Enter Your Password"
            name="password"
            value={password} 
            onChange={e => onInputChange(e)}/>
        </div>
        <div class="form-group form-check">
          <input type="checkbox" className="form-check-input" id="exampleCheck1"/>
          <label class="form-check-label" for="exampleCheck1">Check me out</label>
          <small id="emailHelp" className="form-text text-muted">We'll never share your User Id and Password with anyone else.</small>
        </div>
        <button className="btn btn-primary btn-block">Login</button>
      </form>
      </div>
      </div>
      
   );
}

export default Login;