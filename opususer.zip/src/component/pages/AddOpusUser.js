import './TabCCS.css';
import { useState } from "react";

function AddOpusUser() {
  const [toggleState, setToggleState] = useState(1);

  const toggleTab = (index) => {
    setToggleState(index);
  };

  return (
  
    <div className="container" >
      <div className="bloc-tabs">
        <button
          className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
          onClick={() => toggleTab(1)}
        >
          Person Info
        </button>
        <button
          className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
          onClick={() => toggleTab(2)}
        >
         User Crendential
        </button>
        <button
          className={toggleState === 3 ? "tabs active-tabs" : "tabs"}
          onClick={() => toggleTab(3)}
        >
         Address
        </button>
      </div>
      <form>
      <div className="content-tabs">
        <div
          className={toggleState === 1 ? "content  active-content" : "content"}
        >
        
        <div className="form-group">
            <input 
            type="text" 
            className="form-control form-control-lg"
            placeholder="Enter Your First Name"
            name="first_name"/>
        </div>
        <div className="form-group">
            <input 
            type="text" 
            className="form-control form-control-lg"
            placeholder="Enter Your Last Name"
            name="last_name"/>
        </div>
        <div className="form-group">
        <input 
        type="text" 
        className="form-control form-control-lg"
        placeholder="Enter Your Email"
        name="email"/>
        </div>
       
        </div>

        <div
          className={toggleState === 2 ? "content  active-content" : "content"}
        ><div className="form-group">
        <input 
        type="text" 
        className="form-control form-control-lg"
        placeholder="Enter Your User Id"
        name="user_id"/>
        </div>
        <div className="form-group">
        <input 
        type="password" 
        className="form-control form-control-lg"
        placeholder="Enter Your Password"
        name="password"/>
        </div>

        </div>

        <div
          className={toggleState === 3 ? "content  active-content" : "content"}
        >
<div className="form-group">
        <input 
        type="text" 
        className="form-control form-control-lg"
        placeholder="Enter Address 1"
        name="address1"/>
        </div>
        <div className="form-group">
        <input 
        type="text" 
        className="form-control form-control-lg"
        placeholder="Enter City"
        name="city"/>
        </div>
        <div className="form-group"> 
        <select name="state">
        <option value="#">-Select State-</option>
          <option value="CA">CA</option>
          <option value="LA">LA</option>
          <option value="NY">NY</option>
          <option value="WA">WA</option>
        </select>
        </div>
        <div className="form-group">
        <input 
        type="text" 
        className="form-control form-control-lg"
        placeholder="Enter Zip"
        name="zip"/>
        </div>
                </div>
      </div>
      <button className="btn btn-primary btn-block">Add User</button>
      
        </form>
    </div>
    
  );
}

export default AddOpusUser;
